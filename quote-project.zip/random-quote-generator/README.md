# Random Quote Generator

A responsive website that fetches and displays a random quote and its author from the DummyJSON public API.

## Features
- Fetches a quote when the page loads
- Fetches another quote when **New Quote** is clicked
- Shows a loading message during requests
- Displays a helpful error message if a request fails
- Responsive layout for phones, tablets, and laptops
- Accessible status updates and keyboard-visible button focus

## Built With
- HTML
- CSS
- JavaScript
- Fetch API
- DummyJSON Quotes API

## Run Locally
1. Download or clone this repository.
2. Open `index.html` in a browser, or use the Live Server extension in Visual Studio Code.
3. Keep an internet connection available so the public API can return quotes.

## API
`https://dummyjson.com/quotes/random`

## Deploy with GitHub Pages
1. Upload all project files to a **public** GitHub repository.
2. Open **Settings → Pages**.
3. Under build and deployment, choose **Deploy from a branch**.
4. Choose the `main` branch and `/ (root)`, then save.
5. Wait for deployment and open the URL shown in Pages settings.

## Project Files
- `index.html` — page structure
- `style.css` — visual design and responsive styles
- `script.js` — Fetch API, loading state, and error handling

## Author
Replace this line with your name before submission.
