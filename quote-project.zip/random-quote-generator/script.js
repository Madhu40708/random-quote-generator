const quoteElement = document.getElementById("quote");
const authorElement = document.getElementById("author");
const button = document.getElementById("new-quote");
const statusElement = document.getElementById("status");
const quoteBox = document.querySelector(".quote-box");

let previousQuote = "";

async function getQuote() {
  button.disabled = true;
  quoteBox.setAttribute("aria-busy", "true");
  quoteElement.textContent = "Loading...";
  authorElement.textContent = "";
  statusElement.textContent = "";

  try {
    let quote;

    // Try a few times if the API returns the same quote again.
    for (let attempt = 0; attempt < 5; attempt++) {
      const response = await fetch("https://dummyjson.com/quotes/random");

      if (!response.ok) {
        throw new Error("The quote service returned an error.");
      }

      quote = await response.json();

      if (quote.quote && quote.quote !== previousQuote) {
        break;
      }
    }

    if (!quote || !quote.quote || !quote.author) {
      throw new Error("The quote response was incomplete.");
    }

    previousQuote = quote.quote;
    quoteElement.textContent = `“${quote.quote}”`;
    authorElement.textContent = `— ${quote.author}`;
  } catch (error) {
    quoteElement.textContent = "Oops! We couldn't load a quote.";
    statusElement.textContent =
      "Please check your internet connection and try again.";
  } finally {
    button.disabled = false;
    quoteBox.setAttribute("aria-busy", "false");
  }
}

button.addEventListener("click", getQuote);
getQuote();
